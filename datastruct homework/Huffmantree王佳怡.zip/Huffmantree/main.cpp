#include"HuffmanTree.h"

//INT_MAX

int main() {
	ifstream inputFile("huffman.txt");
	if (!inputFile.is_open()) {
		cerr << "cant open file" << endl;
		return 1;
	}
	HuffmanTree HT;
	InitHT(HT, inputFile);
	CreateHT(HT);
	//�����������
	//Traverse(HT);
	HTcode HTcodes;
	Encode(HT, HTcodes);

	//�������
	for (int i = 0; i < (HT.size + 1)/2; i++) {
		cout << HTcodes.Nodes[i].value<<":  ";
		for (int j = 0; j < HTcodes.Nodes[i].codesize; j++) {
			cout << HTcodes.Nodes[i].code[j];
		}
		//cout << HTcodes.Nodes[i].code;
		cout << endl;
	}
	
	float wpl=HT_WPL(HT);
	cout << "WPL is :" << wpl << endl;
	ifstream input("huffman.txt");
	if (!input.is_open()) {
		cerr << "cant open file" << endl;
		return 1;
	}
	ofstream output("huffman_code.txt");
	if (!output.is_open()) {
		cerr << "cant open file" << endl;
		return 1;
	}


	Transform(HTcodes, input, output);
	output.close();
	//�ɲ�����ֱ�ӵ���Huffmancodetxt��
	ifstream input1("huffman_code.txt");
	if (!input1.is_open()) {
		cerr << "cant open file" << endl;
		return 1;
	}
	//���������û�пո���ô��?
	Decode(HT, input1);
	
	return 0;
}