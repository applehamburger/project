#pragma once
#include<iostream>
#include<fstream>

using namespace std;

typedef int Elemtype1;

typedef struct Linknode {
	Elemtype1 Elem;
	Linknode* next;
	Linknode* top;
}Linknode,*Linkstack;

int Init(Linkstack& L);
int Push(const Linkstack& L, Elemtype1 e);
int Pop(const Linkstack& L, Elemtype1& e);
int IsEmpty(const Linkstack& L);
int GetTop(const Linkstack& L, Elemtype1& e);
void Traverse(const Linkstack& L);
void Clear(Linkstack& L);
void Destroy(Linkstack& L);