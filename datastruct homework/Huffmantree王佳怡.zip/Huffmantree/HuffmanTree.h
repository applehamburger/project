#pragma once
#include<iostream>
#include<fstream>
#include"Linkstack.h"

using namespace std;

#define maxsize 100
typedef char Elemtype;
typedef struct {
	int parent, lchild, rchild;
	Elemtype value;
	float weight;
}TreeNode;

typedef struct {
	TreeNode* node;
	int size;
}HuffmanTree;

typedef struct {
	Elemtype value;
	int* code;
	int codesize;
}HTcodeNode;

typedef struct {
	HTcodeNode* Nodes;
	int size;
}HTcode;

void InitHT(HuffmanTree& HT, ifstream& inputfile);
void Traverse(const HuffmanTree& HT);
void CreateHT(HuffmanTree& HT);
void FindMin(HuffmanTree& HT, int& p1, int& p2);
void Encode(HuffmanTree& HT, HTcode& HTcodes);
void Transform(HTcode& HTcodes, ifstream& input, ofstream& ouput);
float HT_WPL(const HuffmanTree& HT);
void  Decode(const HuffmanTree& HT, ifstream& input);
