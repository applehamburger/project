#include "HuffmanTree.h"

void InitHT(HuffmanTree& HT, ifstream& inputfile)
{
	HT.node = new TreeNode[maxsize];
	HT.size = 0;
	while (inputfile.peek() != EOF) {
		Elemtype t;
		inputfile.get(t);
		bool flag=false;
		int j = 0;
		for (int i = 0; i < HT.size; i++)
		{
			if (HT.node[i].value == t) {
				flag = true;
				j = i;
			}
		}
		if (flag) {
			HT.node[j].weight += 1;
		}
		else {
			HT.node[HT.size].value = t;
			HT.node[HT.size].weight = 1;
			HT.node[HT.size].rchild = -1;
			HT.node[HT.size].lchild = -1;
			HT.node[HT.size].parent = -1;
			HT.size += 1;
		}
	}
}

void Traverse(const HuffmanTree& HT)
{
	if (HT.size == 0) {
		cout << "HT is Empty" << endl;
		return;
	}
	for (int i = 0; i < HT.size; i++) {
		cout << i << ":  ";
		cout << HT.node[i].value << ":";
		cout << HT.node[i].parent << ":";
		cout << HT.node[i].lchild << ":";
		cout << HT.node[i].rchild << ":";
		cout << HT.node[i].weight << endl;
	}

}

void CreateHT(HuffmanTree& HT)
{
	int i;
	int n = HT.size;
	int p1, p2;
	for (i = n; i < n*2-1; i++) {
		FindMin(HT, p1, p2);
		HT.node[i].parent = -1;
		HT.node[i].lchild = p1;
		HT.node[i].rchild = p2;
		HT.node[i].weight = HT.node[p1].weight+ HT.node[p2].weight;
		HT.node[p1].parent = i;
		HT.node[p2].parent = i;
		HT.size++;
	}
}

void FindMin(HuffmanTree& HT, int& p1, int& p2)
{
	int n = HT.size;
	int i;
	p1 = p2 = -1;
	for (i = 0; i < n; i++) {
		if (HT.node[i].parent == -1 && p1==-1) {
			p1 = i;
		}
		else if(HT.node[i].parent == -1 && p2==-1){
			p2 = i;
		}
	}
	if (HT.node[p1].weight > HT.node[p2].weight) {
		int t = p1;
		p1 = p2;
		p2 = t;
	}
	float min1 = HT.node[p1].weight;
	float min2 = HT.node[p2].weight;

	for (i = 2; i < n; i++) {
		if (HT.node[i].parent == -1) {
			if (HT.node[i].weight < min1) {
				min1= HT.node[i].weight;
				p1 = i;
			}
			else if (HT.node[i].weight < min2 && i!=p1) {
				min2 = HT.node[i].weight;
				p2 = i;
			}
		}
	}

}

void Encode(HuffmanTree& HT, HTcode& HTcodes)
{
	int i;
	int n = (HT.size + 1) / 2;
	HTcodes.Nodes = new HTcodeNode[n];
	HTcodes.size = n;
	int p, R, c=0; //c��code���ȣ�
	Linkstack S;
	Init(S);
	for (i = 0; i < n; i++) {
		c = 0;
		p = i;
		R = HT.node[i].parent;
		while (1) {
			if (HT.node[R].lchild == p) {
				Push(S, 0);
				c++;
			}
			else {
				Push(S, 1);
				c++;
			}
			p = R;
			R = HT.node[p].parent;
			if (R == -1) {
				break;
			}
		}
		HTcodes.Nodes[i].value = HT.node[i].value;
		HTcodes.Nodes[i].code = new int[c+1];
		HTcodes.Nodes[i].codesize = c;
		//��ô�򻯵�����c
		
		int j = 0;
		while (!IsEmpty(S)) {
			Pop(S, HTcodes.Nodes[i].code[j]);
			j++;
		}
		//HTcodes.Nodes[i].code[j] = '\0';
		//��code���ַ�����ʱ��ſ���ֱ����cout���
	}
}

void Transform(HTcode& HTcodes, ifstream& input, ofstream& output)
{
	Elemtype x;
	while (input.peek()!=EOF)
	{
		input.get(x);
		for (int i = 0; i < HTcodes.size; i++) {
			if (x == HTcodes.Nodes[i].value) {
				for (int j = 0; j < HTcodes.Nodes[i].codesize; j++) {
					output << HTcodes.Nodes[i].code[j];
				}
			}
		}
	}
	
}

float HT_WPL(const HuffmanTree& HT)
{
	int i;
	int n = (HT.size + 1) / 2;
	int R;
	float WPL=0;
	for (i = 0; i < n; i++) {
		R = HT.node[i].parent;
		int pl = 1;
		while (1) {
			R = HT.node[R].parent;
			if (R == -1) {
				break;
			}
			else {
				pl++;
			}
		}
		WPL += pl * HT.node[i].weight;
	}
	return WPL;
}

void Decode(const HuffmanTree& HT, ifstream& input1)
{
	int p;
	char x;
	while(input1.peek()!=EOF){
		p = HT.size - 1;
		while (1) {
			input1 >> x;
			if (x == '0') {
				p = HT.node[p].lchild;
			}
			else {
				p = HT.node[p].rchild;
			}
			if (HT.node[p].lchild == -1 && HT.node[p].rchild == -1) {
				break;
			}
		}
		cout << HT.node[p].value;
	}
}
