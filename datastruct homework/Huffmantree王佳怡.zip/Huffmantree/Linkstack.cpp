#include "Linkstack.h"

int Init(Linkstack& L)
{
	Linknode* q = new Linknode;
	q->next = NULL;
	q->top = q->next;
	L = q;
	return 0;
}

int Push(const Linkstack& L, Elemtype1 e)
{
	Linknode* p = new Linknode;
	p->Elem = e;
	p->next = L->next;
	L->top = p;
	L->next = p;
	return 0;
}

int Pop(const Linkstack& L, Elemtype1& e)
{
	if (IsEmpty(L)) {
		cerr << "Stack is empty" << endl;
		return 0;
	}
	Linknode* p = L->next;
	L->top = p->next;
	e = p->Elem;
	L->next = p->next;
	return 1;
}

int IsEmpty(const Linkstack& L)
{
	if (L->next == NULL) {
		return 1;
	}
	return 0;
}

int GetTop(const Linkstack& L, Elemtype1& e)
{
	if (IsEmpty(L)) {
		cerr << "Stack is empty" << endl;
		return 0;
	}
	e = L->top->Elem;
	return 1;
}

void Traverse(const Linkstack& L)
{
	if (IsEmpty(L)) {
		cerr << "Stack is empty" << endl;
		return ;
	}
	Linknode* p = L->next;
	while (p) {
		cout << p->Elem << "��";
		p = p->next;
	}
	cout << "end" << endl;
	return;
}

void Clear(Linkstack& L)
{
	Linknode* p = L->next;
	while (p) {
		Linknode* q = p;
		p = p->next;
		delete q;
	}
	L->next = NULL;
}

void Destroy(Linkstack& L) {
	Clear(L);
	delete L;
	L = NULL;
	return;
}
