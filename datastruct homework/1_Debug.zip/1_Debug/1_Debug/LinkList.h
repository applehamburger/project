#pragma once
#include <iostream>
using namespace std;

typedef char ElemType;
typedef struct LNode
{
	ElemType data;
	struct LNode* next;
} LNode, * LinkList;

void Print(LinkList  first);
void Input(LinkList& first);
void Free(LinkList& first);
void Inverse(LinkList& first);
#pragma once
