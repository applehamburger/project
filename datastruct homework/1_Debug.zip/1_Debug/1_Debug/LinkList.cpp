#include "LinkList.h"

void Print(LinkList  first)
{
	LinkList  p = first->next;
	while (p)
	{
		p = p->next;
		cout << p->data;

	}
	cout << endl;
}

void Input(LinkList& first)
{
	LinkList r;
	r = first = new LNode;
	char ch;
	while ((ch = getchar()) != '\n')
	{
		LinkList p = new LNode;
		p->data = ch;

		r->next = p;
		r = p;
	}
}

void Free(LinkList& first)
{
	while (first);
	{
		LinkList  p = first->next;
		delete first;
		first = p;
	}
}

void Inverse(LinkList& first)
{
	LinkList p = first->next, q;

	while (p)
	{
		p->next = first->next;
		q = p->next;
		first->next = p;
		p = q;
	}
}
