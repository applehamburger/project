#include "LinkList.h"

int main()
{
	LinkList  first = NULL;
	Input(first);
	Print(first);
	Inverse(first);
	Print(first);
	Free(first);
	return 0;
}