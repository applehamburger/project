#include"search.h"
Status InitList(SSTable &ST) {
	ST.elem = new ElemType[MAXSIZE];//�����СΪMAXSIZE���ڴ�ռ�
	if (!ST.elem) {
		cout << "ʧ��" << endl;
		return ERROR;
	}
	//����ʧ�����˳�
	ST.length = 0;
	return OK;
}

void CreateST(SSTable& ST, int n) {
	cout << "������Ԫ��" << endl;
	for (int i = 0; i < n; i++) {
		cin >> ST.elem[i].key;
		ST.length++;
	}
}

//int Search(SSTable ST, KeyType key) {
//	ST.elem[0].key = key;
//	for (int i = ST.length; ST.elem[i].key != key; --i)
//			return i;
//}

////�ǵݹ���ֲ���
//int Search_Bin(SSTable ST, KeyType key) {
//	KeyType low, high,mid;
//	low = 1; high = ST.length;
//	while (low < high) {
//		mid = (low + high) / 2;
//		if (key == ST.elem[mid].key)  return mid;
//		else if (key < ST.elem[mid].key) high = mid - 1;
//		else low = mid + 1;
//	}
//}
//
////�ݹ���ֲ���
//int BinSearch(SSTable L, KeyType x, int low, int high) {
//	 int mid = 0;
//	 if (low <= high) {
//		 mid = (low + high) / 2;
//		 if (L.elem[mid].key < x)
//			 mid = BinSearch(L, x, mid + 1, high);
//		 else if (L.elem[mid].key > x)
//			 mid = BinSearch(L, x, low, mid - 1);
//		
//	}
//	 return mid;
//	
//}
