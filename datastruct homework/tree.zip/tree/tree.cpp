#include<iostream>
#include<fstream>
using namespace std;
typedef char ElemType;
ifstream fin;

typedef struct BiTNode {
	ElemType data;
	BiTNode* lchild, *rchild;
}BiTNode,*BiTree;

//ջ�Ķ������غ���
#define SElemType BiTNode*
#define MAXSIZE 100
#define OVERFLOW -1
typedef struct {
	SElemType* base;
	SElemType* top;
	int stacksize;
} Sstack;
enum Status {
	ERROR,     // ִ�гɹ�
	OK  // ִ��ʧ��
};
Status InitStack(Sstack& S) {
	S.base = new SElemType[MAXSIZE];
	if (!S.base) exit(OVERFLOW);
	S.top = S.base;
	S.stacksize = MAXSIZE;
	return OK;
}
Status Push(Sstack& S, BiTNode* e) {
	if (S.top - S.base == S.stacksize) return ERROR;
	*S.top++ = e;
	return OK;
}
Status Pop(Sstack& S, BiTNode*& e) {
	if (S.top == S.base) return ERROR;
	e = *--S.top;
	return OK;
}
bool StackEmpty(const Sstack& S) {
	if (S.top == S.base)
		return true;
	else
		return false;
}

void PreOrdered(BiTree T) {
	Sstack S;
	InitStack(S);
	BiTNode* p = T;
	while (p != NULL || S.top != S.base) {
		if (p != NULL) {
			cout << p->data;
			Push(S, p);
			p = p->lchild;
		}
		else {
			Pop(S, p);
			p = p->rchild;
		}
	}
}
void InOrdered(BiTree T) {
	Sstack S;
	InitStack(S);
	BiTree p = T;
	do {
		while (p != NULL) {
			Push(S, p);
			p = p->lchild;
		}
		if (!StackEmpty(S)) {
			Pop(S, p);
			cout << p->data;
			p = p->rchild;
		}
	} while (p != NULL || !StackEmpty(S));
}

Status Traverse(const Sstack& S) {

	int i;
	for (i = 0; i < (S.top - S.base); i++) {
		cout << S.base[i] << " ";
	}
	cout << endl;
	return OK;
}
void PreOrderCreate(BiTree& T) {
	char c;
	fin >> c;
	if (c=='#') {
		T = NULL;
	}
	else{
		T = new BiTNode;
		T->data = c;
		cout <<T->data << " ";
		PreOrderCreate(T->lchild);
		PreOrderCreate(T->rchild);
	}
}

//������ز���
typedef BiTree QElemType;
typedef struct QNode {
	QElemType data;
	struct QNode* next;
}QNode, * QueuePtr;
typedef struct {
	QueuePtr front;
	QueuePtr rear;
}LinkQueue;
Status InitQueue(LinkQueue& Q) {
	Q.front = Q.rear = new QNode;
	Q.front->next = NULL;
	return OK;
}
Status QueueTraverse(LinkQueue Q) {
	QueuePtr p = Q.front->next;
	while (p != NULL) {
		cout << p->data->data << " ";
		p = p->next;
	}
	cout << endl;
	return OK;
}
Status EnQueue(LinkQueue& Q, QElemType e) {
	QueuePtr p = new QNode;
	p->data = e;
	p->next = NULL;
	Q.rear->next = p;
	Q.rear = p;
	return OK;
}
bool isEmpty(const LinkQueue& Q) {
	return Q.front == Q.rear;
}
Status DeQueue(LinkQueue& Q, QElemType& e) {
	if (isEmpty(Q)) return ERROR;
	QueuePtr p = Q.front->next;
	e = p->data;
	Q.front->next = p->next;
	if (Q.rear == p)
		Q.rear = Q.front;
	delete p;
	return OK;
}
void LevelOrder(BiTree T) {
	LinkQueue Q;
	InitQueue(Q);
	BiTree p = T;
	if (p) {
		EnQueue(Q, p);
		while (!isEmpty(Q)) {
			DeQueue(Q, p);
			cout << p->data;
			if (p->lchild)
				EnQueue(Q, p->lchild);
			if (p->rchild)
				EnQueue(Q, p->rchild);
		}
	}
}

//������
int n = 0;
Status leaf(BiTree T) {
	if (T != NULL) {
		if (T->lchild == NULL && T->rchild == NULL)
			n++;
		leaf(T->lchild);
		leaf(T->rchild);
	}
	return OK;
}
int NodeCount(BiTree T) {
	if (T == NULL) return 0;
	else return NodeCount(T->lchild) + NodeCount(T->rchild) + 1;
}
int Depth(BiTree T)
{
	int m, n;
	if (T == NULL)
		return 0;
	else {
		m = Depth(T->lchild);
		n = Depth(T->rchild);
		if (m > n) return (m + 1);
		else return (n + 1);
	}
}

Status PreorderKnode(BiTree T, ElemType& e, int& count) {
	if (T == NULL) return ERROR;
	count++;
	if (count == 2) {
		e = T->data;
		return OK;
	}
	else if (count > 2) return ERROR;
	else {
		if (PreorderKnode(T->lchild, e, count) == ERROR)
			return PreorderKnode(T->rchild, e, count);
		return OK;
	}

}

void deleteXTree(BiTree& T, ElemType x) {
	if (T != NULL) {
		if (T->data == x)delete BiTree(T);
		else {
			deleteXTree(T->lchild, x);
			deleteXTree(T->rchild, x);
		}
	}
}

void deleteBiTree(BiTree& T) {
	if (T != NULL) {
		deleteBiTree(T->lchild);
		deleteBiTree(T->rchild);
	}
}

void PreOrder(BiTree T) {
	if (T) {
		cout << T->data << " ";
		PreOrder(T->lchild);
		PreOrder(T->rchild);
	}
}

void InOrder(BiTree T) {
	if (T != NULL) {
		InOrder(T->lchild);
		cout << T->data << " ";
		InOrder(T->rchild);
	}
}

void PostOrder(BiTree T) {
	if (T != NULL) {
		PostOrder(T->lchild);
		PostOrder(T->rchild);
		cout << T->data << " ";
	}
}

int main() {
	BiTree T = NULL;
	Sstack S;
	LinkQueue Q;
	fin.open("data.txt");
	cout << "����:";
	PreOrderCreate(T);
	cout << endl;
	cout << "����:";
	PreOrder(T);
	cout << endl;
	cout << "����:";
	InOrder(T);
	cout << endl;
	cout << "����:";
	PostOrder(T);
	cout << endl;

	cout << "�ǵݹ�����������Ϊ:";
	PreOrdered(T);
	cout << endl;
	cout << "�ǵݹ�����������Ϊ:";
	InOrdered(T);
	cout << endl;
	cout << "��α������Ϊ:";
	LevelOrder(T);
	cout << endl;
	n = leaf(T);
	cout << "�ܽ����Ϊ:" << NodeCount(T) << endl;
	cout << "Ҷ�ӽڵ���Ϊ:"<<n<<endl;
	cout << "��Ҷ�ӽ����Ϊ:" << NodeCount(T) - n << endl;
	cout<<"�������Ϊ:"<<Depth(T)<<endl;
	ElemType e; int c = 0;
	cout << "�ڶ�������ֵΪ:" << PreorderKnode(T, e, c) << endl;
	ElemType x;
	x = PreorderKnode(T, e, c);
	deleteXTree(T,x);
	//�ͷſռ�
	deleteBiTree(T);

	fin.close();
	return 0;
}





/*int main() {
	BiTree T = NULL;
	Sstack S;
	fin.open("data.txt");
	cout << "���:";
	PreOrderCreate(T);
	cout << endl;
	cout << "����:";
	PreOrder(T);
	cout << endl;
	cout << "����:";
	InOrder(T);
	cout << endl;
	cout << "����:";
	PostOrder(T);
	cout << endl;
	PreOrdered(T);
	Traverse(S);
	fin.close();
    return 0;
}*/