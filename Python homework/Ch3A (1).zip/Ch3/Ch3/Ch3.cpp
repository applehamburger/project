﻿// Ch3.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//第三章 第二次上机

#include <iostream>
#include <string>

using namespace std;

// v0.1
/*
class CMobilePhone {
private:
	//在这里写属性
	string m_name;
	string m_type;
	double m_h, m_l, m_w;
public:
	//在这里写方法
	void setName(string n) {
		m_name = n;    // 为什么能在这里用m_name？
	}
	void setType(string t) {
		m_type = t;
	}
	void setSize(double h = 18.0, double l = 80.8, double w = 40.4) {
		//偷懒，设置默认参数
		m_h = h;
		m_l = l;     // 这个字母是“jkl”的“l”，不是“123”的“1” 
		m_w = w;
	}
	void setInfo(string n, string t, double h=18.0, double l=80.8, double w=40.4) {
		setName(n);
		setType(t);
		setSize(h, l, w);
	}
	void showInfo() {
			//注意：这个函数没有参数！不需要设置参数。为什么？good good think
		cout << "手机名称：" << m_name << " 手机型号：" << m_type << endl;  //这里是“jkl”
		cout << "手机尺寸：长度（mm）：" << m_l << "宽度（mm）：" << m_w << "高度（mm）："<<m_h << endl;
	}
	void call(string someone) {
		cout << "打电话给：" << someone << endl;
	}
};

*/

//v0.2  
/*
class CMobilePhone {
private:
	//在这里写属性
	string m_name;
	string m_type;
	double m_h, m_l, m_w;
public:

	//在这里写构造函数的**声明**，我们把函数的**实现**，写在类定义的后面
	CMobilePhone(string n, string t, double h = 18.0, double l = 80.8, double w = 40.4);
										//如果要写默认参数，在定义的时候写。不要重复写。
	CMobilePhone();


	//在这里写具体方法
	void setName(string n) {
		m_name = n;    // 为什么能在这里用m_name？
	}
	void setType(string t) {
		m_type = t;
	}
	void setSize(double h = 18.0, double l = 80.8, double w = 40.4) {
		//偷懒，设置默认参数
		m_h = h;
		m_l = l;     // 这个字母是“jkl”的“l”，不是“123”的“1” 
		m_w = w;
	}
	void setInfo(string n, string t, double h = 18.0, double l = 80.8, double w = 40.4) {
		setName(n);
		setType(t);
		setSize(h, l, w);
	}
	void showInfo() {
		//注意：这个函数没有参数！不需要设置参数。为什么？good good think
		cout << "手机名称：" << m_name << " 手机型号：" << m_type << endl;  //这里是“jkl”
		cout << "手机尺寸：长度（mm）：" << m_l << "宽度（mm）：" << m_w << "高度（mm）：" << m_h << endl;
	}
	void call(string someone) {
		cout << "使用"<<m_name<<"打电话给：" << someone << endl;
	}
};

CMobilePhone::CMobilePhone(string n, string t, double h, double l, double w)
{
	m_name = n;
	m_type = t;
	m_h = h;
	m_l = l;
	m_w = w;
}   
//很多同学在函数结尾处加上一个额外的“;”,为啥？
//是不需要加的。


CMobilePhone::CMobilePhone()
{
	//没有参数，但同样要做初始化
	m_name = "NONAME";
	m_type = "NOTYPE";
	m_h = 0.0;
	m_l = 0.0;
	m_w = 0.0;
}


*/



//v0.3

class CMobilePhone {
private:
	//在这里写属性
	string m_name;
	string m_user;
	string m_num;
    const string m_type;    //常量属性
	const double m_h, m_l, m_w;    //常量属性
public:
	//在这里写构造函数的**声明**，我们把函数的**实现**，写在类定义的后面
	CMobilePhone(string n, string u, string num, string t, double h = 18.0, double l = 80.8, double w = 40.4);
	//如果要写默认参数，在定义的时候写。不要重复写。
	CMobilePhone();
	//在这里写具体方法
	void setName(string n) {
		m_name = n;    // 为什么能在这里用m_name？
	}
	void setUser(string u) {
		m_user = u;
	}
	void setNum(string num) {
		m_num = num;
	}
	void setInfo(string n, string u, string num){
		setName(n);
		setUser(u);
		setNum(num);
	}
	void showInfo() {
		//注意：这个函数没有参数！不需要设置参数。为什么？good good think
		cout << "手机名称：" << m_name << " 手机型号：" << m_type << endl;  //这里是“jkl”
		cout << "手机尺寸：长度（mm）：" << m_l << "宽度（mm）：" << m_w << "高度（mm）：" << m_h << endl;
		cout << "手机使用者：" << m_user << " 手机号码：" << m_num << endl;
	}
	void call(string someone) {
		cout << m_user<<"使用" << m_name << "打电话给：" << someone << endl;
	}
};

CMobilePhone::CMobilePhone(string n, string u, string num, string t, double h, double l, double w)
		:m_type(t),m_h(h),m_l(l),m_w(w)
{				//通过初始化列表，为const属性赋初值
	m_name = n;
	m_user = u;
	m_num = num;

	//m_type = t;    //const属性，不能再直接赋值
	//m_h = h;
	//m_l = l;
	//m_w = w;
}
//很多同学在函数结尾处加上一个额外的“;”,为啥？
//是不需要加的。


CMobilePhone::CMobilePhone():m_type("NOTYPE"), m_h(0.0), m_l(0.0), m_w(0.0)
{										//在初始化时，直接赋值
	//没有参数，但同样要做初始化
	m_name = "NONAME";
	m_user = "NOUSER";
	m_num = "13000000000";	
}




int main()
{

	//测试v0.1 代码
	//CMobilePhone ph1;
	//ph1.setInfo("苹果", "apple 13 max");
	//ph1.showInfo();
	//ph1.call("李二花");

	//测试v0.2 代码
	/*
	CMobilePhone ph2;
	CMobilePhone ph3("小米手机世界最棒", "13pro");    //使用一些默认参数
	ph2.showInfo();
	ph3.showInfo();
	ph2.call("王大花");
	ph3.call("Tony");
	//定义并使用指针对象
	CMobilePhone* pph4 = new CMobilePhone();
	CMobilePhone* pph5 = new CMobilePhone("我爱华为手机", "p50");
	pph4->showInfo();
	pph5->showInfo();
	delete pph4;
	delete pph5;
	*/


	//测试v0.3
	CMobilePhone ph6;
	CMobilePhone ph7("小米","张三","13322221111", "13pro");    //使用一些默认参数
	ph6.showInfo();
	ph7.showInfo();
	ph6.call("王大花");
	ph7.call("Tony");
	

	return 0;
}
