
# coding: utf-8

# In[1]:


def print_line(n, line, digit):
    if digit == 5:
        if line == 0 or line == n - 2 or line == 2 * n - 4:
            return '0' * n
        elif line < n - 2:
            return '0'
        else:
            return '0'.rjust(n)

    if digit == 8:
        if line == 0 or line == n - 2 or line == 2 * n - 4:
            return '0' * n
        else:
            return '0' + ' '.rjust(n - 2) + '0'


def print_digits(n, choice):
    height = 2 * n - 3

    if choice == 85:
        for i in range(height):
            print(print_line(n, i, 8) + " " + print_line(n, i, 5))
    else:
        for i in range(height):
            print(print_line(n, i, choice))


def tower(n, choice):
    if not (4 <= n <= 20) or int(choice) not in [5, 8, 85]:
        print('Invalid input')
    else:
        print_digits(n, int(choice))



def get_input():
    while True:
        n = input("请输入n（4 <= n <= 20）: ")
        if n.isdigit():
            n = int(n)
            if 4 <= n <= 20:
                break
        print("无效的输入，请重新输入。")

    while True:
        choice = input("请输入choice（5, 8, 85）: ")
        if choice in ["5", "8", "85"]:
            break
        print("无效的输入，请重新输入。")

    tower(n, choice)

get_input()

