
# coding: utf-8

# In[3]:


#3.1 
with open('C:\Users\lenovo\Downloads\IdiomPY.txt', 'r', encoding='gbk') as f:
    idioms = [line[:4] for line in f.readlines()]
# 输出成语的总数
print(f"成语的总数：{len(idioms)}")

