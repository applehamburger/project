
# coding: utf-8

# In[4]:


#3.4与用户交互，先在屏幕打印一个“九宫格”，
#如果用户正确输入了九宫格中包含的成语，则显示猜中了并在屏幕打印新的一个“九宫格”，
#直到用户猜错为止（退出）
while True:
    # 随机选择一个成语
    selected_idiom = random.choice(idioms)
    jiugongge = list(selected_idiom)
    characters = {char for idiom in idioms for char in idiom} - set(jiugongge)
    while len(jiugongge) < 9:
        jiugongge.append(random.choice(list(characters)))
        characters -= set(jiugongge[-1])
    random.shuffle(jiugongge)
    for i in range(0, 9, 3):
        print(jiugongge[i], jiugongge[i + 1], jiugongge[i + 2])
    guess = input("请输入你猜的成语：")
    if guess == selected_idiom:
        print("猜中了！")
    else:
        print(f"猜错了，正确答案是：{selected_idiom}")
        break

