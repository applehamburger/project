
# coding: utf-8

# In[2]:


#2.4 计算拥有多种词性的词的数量：
# 创建一个字典，键为词，值为词性集合
word_sign_dict = {}
for line in lines:
    for word_sign in line.split():
        if '/' in word_sign:
            word, sign = word_sign.rsplit('/', maxsplit=1)
            if word in word_sign_dict:
                word_sign_dict[word].add(sign)
            else:
                word_sign_dict[word] = set([sign])

multiple_sign_words = [word for word, signs in word_sign_dict.items() if len(signs) > 1]
print(len(multiple_sign_words))

