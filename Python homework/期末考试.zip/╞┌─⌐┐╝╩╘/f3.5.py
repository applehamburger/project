
# coding: utf-8

# In[5]:


# 3.5
selected_idiom = random.choice(idioms)
jiugongge = list(selected_idiom)
characters = 
while len(jiugongge) < 9:
    jiugongge.append(random.choice(list(characters)))
    characters -= set(jiugongge[-1])
for i in range(0, 9, 3):
    print(jiugongge[i], jiugongge[i + 1], jiugongge[i + 2])
# 猜成语
possible_idioms = (char in jiugongge for char in idiom)
guess = random.choice(possible_idioms)
print("猜测是：(guess)")

