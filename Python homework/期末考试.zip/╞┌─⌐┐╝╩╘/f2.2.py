
# coding: utf-8

# In[2]:


#2.2向桌面的文件single.txt输出语料中所有的一字词，一字词之间以/分隔
desktop_path = r'C:\Users\lenovo\Downloads\199801.txt\single.txt'
with open(desktop_path, 'w', encoding='utf-8') as f:
    f.write('/'.join(single_words))
    

