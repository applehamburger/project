
# coding: utf-8

# In[2]:


#2.3 输出词性频次前五的名词、动词、形容词和标点符号：
# 分离词和词性
word_sign = [word.rsplit('/', maxsplit=1) for line in lines for word in line.split() if '/' in word]
# 分别找出名词、动词、形容词和标点符号
n = [word for word, sign in word_sign if sign == 'n']
v = [word for word, sign in word_sign if sign  == 'v']
adj = [word for word, sign in word_sign if sign  == 'a']
pn = [word for word, sign in word_sign if sign  == 'w']
for word, freq in Counter(n).most_common(5):
    print(f'名词: {word} {freq}')
for word, freq in Counter(v).most_common(5):
    print(f'动词: {word} {freq}')
for word, freq in Counter(adj).most_common(5):
    print(f'形容词: {word} {freq}')
for word, freq in Counter(pn).most_common(5):
    print(f'标点符号: {word} {freq}')
    

