
# coding: utf-8

# In[2]:


#2.5 找出词性最多的词
max_sign_word = max(word_sign_dict, key=lambda x: len(word_sign_dict[x]))
print(max_sign_word)

