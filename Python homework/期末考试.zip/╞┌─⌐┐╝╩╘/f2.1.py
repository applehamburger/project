
# coding: utf-8

# In[2]:


#2.1 输出词频前十的词：
from collections import Counter

words = [word.split('/')[0] for line in lines for word in line.split() if '/' in word]
word_freq = Counter(words)
for word, freq in word_freq.most_common(10):
    print(word, freq)

