
# coding: utf-8

# In[3]:


#3.2 计算并输出不同汉字的种数
characters = {char for idiom in idioms for char in idiom}
print(f"不同汉字的种数：{len(characters)}")

