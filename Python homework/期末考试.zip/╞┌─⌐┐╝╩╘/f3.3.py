
# coding: utf-8

# In[3]:


#3.3
import random
selected_idiom = random.choice(idioms)
jiugongge = list(selected_idiom)
characters -= set(jiugongge)
while len(jiugongge) < 9:
    jiugongge.append(random.choice(list(characters)))
    characters -= set(jiugongge[-1])
# 打乱汉字的顺序
random.shuffle(jiugongge)
for i in range(0, 9, 3):
    print(jiugongge[i], jiugongge[i + 1], jiugongge[i + 2])

